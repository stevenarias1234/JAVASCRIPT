function validanputs(){
    let email=document.getElementsByID("email");// baja info
    let password=document.getElementById("password");// baja info
    let ingreso=document.getElementById("login");//baja info
    let emailval=email.value.trim();//eliminar espacios innecesarios
    let passwordval=password.value.trim();
    let passwordok="a12345";//clave real ingreso
    //SECCION DE VALIDA DE CAMPOS FORMULARIO CAMPO X CAAMPO
    var error=0; // no ocurre evento error = 0
    // Validar Email
    if (emailval===""){
        ocErrorform(email,"porfavor ingrese su email..");
        errorf=1; // ocurre evento error =1
    }else if(!valEmail(email)){
        ocErrorform(email,"email no valido..");
        errorf=1; // ocurre evento error =1
    }else{
        exitosform(email);
    }
    //Validar contraseña ingresada
    if (passwordval===""){
        ocErrorform(password,"por favor ingrse su contraseña....");
        errorf=1; // ocurre evento error =1
    }else if(passwordval!=passwordok){
        ocErrorform(password,"contraseña no valida....");
        errorf=1; // ocurre evento error =1

    }else{
        exitosform(password);
    }
    // SECCION DE INGRESO EXITOSO EN CAMPOS FORM
    if (errorf==0){
        ingreso.addEventListener("click",function(){
            swal("ACCESO PERMITIDO !!", "Click OK para continuar", "success");
        })
    }
    return false;
    // función para validar errores en formularios
    function ocErrorform (input, message){
        let formControl=input.parentElement;
        let small=formControl.querySelector("small");
        formControl.className="form-control error";
        small.innerText =message; 
     }
     // función para ingreso exitoso en formularios
     function exitosform (input){
         let formControl=input.parentElement;
             formControl.className="form-control success";
         }
     function valEmail(email){
     return /^[a-z0-9_\.-]+@[a-z\.-]+\.[a-z\.]{2,6}$/.test(email);
     }
}